<html>
<head>
<!-- Latest compiled and minified CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Latest compiled JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<div class="container p-5 my-5 bg-primary text-white"> 
    
<h2><div class="well text-center" style="color:gold; font-family:Goudy Old Style"><strong><em>EDUVENTURE ATTENDANCE SYSTEM </em></strong></div></h2>

</div>




</html>